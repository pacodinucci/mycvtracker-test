export const InterviewTopics = [
  { label: "HR", value: "HR", levels: 1 },
  { label: "Java", value: "java", levels: 5 },
  { label: ".Net", value: ".net", levels: 5 },
  { label: "AI", value: "AI", levels: 5 },
  { label: "AGILESCRUM", value: "AGILESCRUM", levels: 5 },
  { label: "Angular", value: "angular", levels: 5 },
  { label: "AWS", value: "AWS", levels: 5 },
  { label: "Azure", value: "AZURE", levels: 5 },
  { label: "C", value: "c", levels: 5 },
  { label: "C++", value: "c++", levels: 5 },
  { label: "CSharp", value: "CSharp", levels: 5 },
  { label: "CORDA", value: "CORDA", levels: 5 },
  { label: "Docker", value: "Docker", levels: 5 },
  { label: "GIT", value: "GIT", levels: 5 },
  { label: "Go", value: "Go", levels: 5 },
  { label: "HR", value: "HR", levels: 5 },
  { label: "Javascript", value: "javascript", levels: 5 },
  { label: "Kubernetes", value: "Kubernetes", levels: 5 },
  { label: "microservices", value: "microservices", levels: 5 },
  { label: "Nodejs", value: "nodejs", levels: 5 },
  { label: "Personality", value: "PERSONALITY", levels: 5 },
  { label: "Product Manager01", value: "ProductManager", levels: 5 },
  { label: "Python", value: "python", levels: 5 },
  { label: "ReactJS", value: "reactjs", levels: 5 },
  { label: "React Native", value: "rnative", levels: 5 },
  { label: "Ruby", value: "Ruby", levels: 5 },
  { label: "Typescript", value: "typescript", levels: 5 },
];


export const RecruiterParty = [

   { id:1, type: "EMPLOYER" },
   { id:2, type: "REFERRAL" },
   { id:3, type: "RECRUITER_PARTY" },

];
