export type AlertsType = {
  [key: string]: {
    type: string;
    message: string;
  };
};
