export type ComponentColor = "primary" | "secondary" | "warning" | "success" | "danger" | "muted" |
  "blue" | "light-blue" | "light-blue-2" | "dark-blue" | "green" | "light-green" | "dark-green" | "red" | "yellow" |
  "pink" | "purple" | "orange" | "white" | "gray" | "light-gray-1" | "light-gray-2" | "light-gray-3" | "light-gray-4" |
  "light-gray-5" |
  "dark-gray" | "black";
